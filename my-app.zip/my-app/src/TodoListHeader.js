import React, {Component} from 'react'

const TodoListHeader = () =><h2>Todo List</h2>;

export default TodoListHeader;